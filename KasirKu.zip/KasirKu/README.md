# KasirKu

Aplikasi kasir (POS) Android orisinal, dibuat dengan Kotlin + Jetpack Compose + Room.

## Fitur
- **Kasir**: cari produk, keranjang, diskon, pembayaran Tunai/QRIS/Transfer, kembalian otomatis
- **Produk & stok**: tambah, ubah, hapus produk; stok berkurang otomatis saat transaksi
- **Struk**: cetak ke printer thermal 58mm via Bluetooth (ESC/POS) atau bagikan sebagai teks (WhatsApp, dll.)
- **Laporan**: omzet, laba, jumlah transaksi, produk terlaris, riwayat (hari ini / 7 hari / bulan ini)
- **Printer**: pilih printer Bluetooth yang sudah dipasangkan dan atur nama toko untuk struk

Data tersimpan offline di perangkat (SQLite lewat Room).

## Cara build
1. Buka folder ini di **Android Studio** (Koala atau lebih baru), tunggu Gradle sync.
2. Jalankan di emulator atau HP (Android 7.0 / API 24 ke atas).
3. Untuk APK: menu **Build > Build Bundle(s) / APK(s) > Build APK(s)**.

Catatan: wrapper Gradle (`gradlew`) tidak disertakan; Android Studio akan menanganinya.
Proyek ini belum dikompilasi di lingkungan pembuatnya, jadi jika ada galat sync atau build, kirimkan pesannya agar bisa diperbaiki.

## Struktur
- `data/` entitas dan database Room
- `ui/` ViewModel dan layar Compose
- `print/` format struk dan pencetak Bluetooth
