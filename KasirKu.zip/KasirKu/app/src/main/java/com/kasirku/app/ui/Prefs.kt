package com.kasirku.app.ui

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.Composable
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.platform.LocalContext
import androidx.core.content.ContextCompat

class Prefs(context: Context) {
    private val sp = context.getSharedPreferences("kasirku", Context.MODE_PRIVATE)

    var storeName: String
        get() = sp.getString("store", "Toko Saya") ?: "Toko Saya"
        set(v) { sp.edit().putString("store", v).apply() }

    var printerAddress: String?
        get() = sp.getString("printer", null)
        set(v) { sp.edit().putString("printer", v).apply() }

    var printerName: String?
        get() = sp.getString("printer_name", null)
        set(v) { sp.edit().putString("printer_name", v).apply() }
}

/** Mengembalikan fungsi yang meminta izin Bluetooth (Android 12+) lalu menjalankan [onGranted]. */
@Composable
fun rememberBtPermission(onGranted: () -> Unit): () -> Unit {
    val ctx = LocalContext.current
    val cb = rememberUpdatedState(onGranted)
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) cb.value()
    }
    return {
        val granted = Build.VERSION.SDK_INT < Build.VERSION_CODES.S ||
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.BLUETOOTH_CONNECT) ==
            PackageManager.PERMISSION_GRANTED
        if (granted) cb.value() else launcher.launch(Manifest.permission.BLUETOOTH_CONNECT)
    }
}
