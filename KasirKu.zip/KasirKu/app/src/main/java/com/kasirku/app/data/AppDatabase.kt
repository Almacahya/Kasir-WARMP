package com.kasirku.app.data

import android.content.Context
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.Transaction
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface AppDao {
    @Query("SELECT * FROM products ORDER BY name COLLATE NOCASE")
    fun products(): Flow<List<Product>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertProduct(p: Product): Long

    @Delete
    suspend fun deleteProduct(p: Product)

    @Query("UPDATE products SET stock = stock - :qty WHERE id = :id")
    suspend fun reduceStock(id: Long, qty: Int)

    @Insert
    suspend fun insertSale(s: Sale): Long

    @Insert
    suspend fun insertItems(items: List<SaleItem>)

    @Query("SELECT * FROM sales WHERE timestamp BETWEEN :from AND :to ORDER BY timestamp DESC")
    fun salesBetween(from: Long, to: Long): Flow<List<Sale>>

    @Query(
        "SELECT COALESCE(SUM((price - cost) * qty), 0) FROM sale_items " +
            "WHERE saleId IN (SELECT id FROM sales WHERE timestamp BETWEEN :from AND :to)"
    )
    fun profitBetween(from: Long, to: Long): Flow<Long>

    @Query(
        "SELECT productName AS name, SUM(qty) AS qty FROM sale_items " +
            "WHERE saleId IN (SELECT id FROM sales WHERE timestamp BETWEEN :from AND :to) " +
            "GROUP BY productName ORDER BY qty DESC LIMIT 5"
    )
    fun topProducts(from: Long, to: Long): Flow<List<TopProduct>>

    @Query("SELECT * FROM sale_items WHERE saleId = :saleId")
    suspend fun itemsOf(saleId: Long): List<SaleItem>

    @Transaction
    suspend fun checkout(sale: Sale, items: List<SaleItem>): Long {
        val id = insertSale(sale)
        insertItems(items.map { it.copy(saleId = id) })
        items.forEach { reduceStock(it.productId, it.qty) }
        return id
    }
}

@Database(entities = [Product::class, Sale::class, SaleItem::class], version = 1, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {
    abstract fun dao(): AppDao

    companion object {
        @Volatile private var instance: AppDatabase? = null

        fun get(context: Context): AppDatabase = instance ?: synchronized(this) {
            instance ?: Room.databaseBuilder(
                context.applicationContext, AppDatabase::class.java, "kasirku.db"
            ).build().also { instance = it }
        }
    }
}
