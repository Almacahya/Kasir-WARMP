package com.kasirku.app.print

import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothManager
import android.content.Context
import com.kasirku.app.ui.ReceiptData
import com.kasirku.app.ui.rupiah
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

private val SPP_UUID: UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")
private const val WIDTH = 32 // printer 58mm

object ReceiptFormatter {
    fun text(storeName: String, r: ReceiptData): String {
        val df = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale("id", "ID"))
        val sb = StringBuilder()
        sb.appendLine(center(storeName))
        sb.appendLine(center(df.format(Date(r.sale.timestamp))))
        sb.appendLine("No: #${r.sale.id}")
        sb.appendLine("-".repeat(WIDTH))
        r.items.forEach {
            sb.appendLine(it.productName.take(WIDTH))
            sb.appendLine(twoCol("  ${it.qty} x ${rupiah(it.price)}", rupiah(it.price * it.qty)))
        }
        sb.appendLine("-".repeat(WIDTH))
        sb.appendLine(twoCol("Subtotal", rupiah(r.sale.subtotal)))
        if (r.sale.discount > 0) sb.appendLine(twoCol("Diskon", "-" + rupiah(r.sale.discount)))
        sb.appendLine(twoCol("TOTAL", rupiah(r.sale.total)))
        sb.appendLine(twoCol("Bayar (${r.sale.method})", rupiah(r.sale.paid)))
        if (r.sale.paid > r.sale.total) sb.appendLine(twoCol("Kembali", rupiah(r.sale.paid - r.sale.total)))
        sb.appendLine("-".repeat(WIDTH))
        sb.appendLine(center("Terima kasih"))
        return sb.toString()
    }

    private fun center(s: String): String {
        val t = s.take(WIDTH)
        return " ".repeat(((WIDTH - t.length) / 2).coerceAtLeast(0)) + t
    }

    private fun twoCol(l: String, r: String): String {
        val space = (WIDTH - l.length - r.length).coerceAtLeast(1)
        return l + " ".repeat(space) + r
    }
}

class BluetoothPrinter(private val context: Context) {
    private val adapter: BluetoothAdapter? =
        (context.getSystemService(Context.BLUETOOTH_SERVICE) as? BluetoothManager)?.adapter

    @SuppressLint("MissingPermission")
    fun pairedDevices(): List<BluetoothDevice> = try {
        adapter?.bondedDevices?.toList().orEmpty()
    } catch (e: SecurityException) {
        emptyList()
    }

    @SuppressLint("MissingPermission")
    suspend fun print(address: String, text: String): Result<Unit> = withContext(Dispatchers.IO) {
        runCatching {
            val device = adapter?.getRemoteDevice(address) ?: error("Bluetooth tidak tersedia")
            val socket = device.createRfcommSocketToServiceRecord(SPP_UUID)
            try {
                adapter.cancelDiscovery()
                socket.connect()
                val out = socket.outputStream
                out.write(byteArrayOf(0x1B, 0x40)) // reset printer
                out.write(text.toByteArray(Charsets.ISO_8859_1))
                out.write(byteArrayOf(0x0A, 0x0A, 0x0A, 0x0A))
                out.flush()
            } finally {
                runCatching { socket.close() }
            }
        }
    }
}
