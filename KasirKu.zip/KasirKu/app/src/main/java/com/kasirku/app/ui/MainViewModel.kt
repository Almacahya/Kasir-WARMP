package com.kasirku.app.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.kasirku.app.data.AppDatabase
import com.kasirku.app.data.CartLine
import com.kasirku.app.data.Product
import com.kasirku.app.data.Sale
import com.kasirku.app.data.SaleItem
import com.kasirku.app.data.TopProduct
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.text.NumberFormat
import java.util.Calendar
import java.util.Locale

fun rupiah(v: Long): String =
    "Rp " + NumberFormat.getNumberInstance(Locale("id", "ID")).format(v)

enum class ReportRange(val label: String) { TODAY("Hari ini"), WEEK("7 hari"), MONTH("Bulan ini") }

data class ReportState(
    val sales: List<Sale> = emptyList(),
    val profit: Long = 0,
    val top: List<TopProduct> = emptyList()
) {
    val revenue: Long get() = sales.sumOf { it.total }
}

data class ReceiptData(
    val sale: Sale,
    val items: List<SaleItem>
)

@OptIn(ExperimentalCoroutinesApi::class)
class MainViewModel(app: Application) : AndroidViewModel(app) {
    private val dao = AppDatabase.get(app).dao()

    val products: StateFlow<List<Product>> =
        dao.products().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // ---- Kasir ----
    val search = MutableStateFlow("")
    val cart = MutableStateFlow<Map<Long, Int>>(emptyMap())
    val discount = MutableStateFlow(0L)
    val lastReceipt = MutableStateFlow<ReceiptData?>(null)

    val filtered: StateFlow<List<Product>> = combine(products, search) { list, q ->
        if (q.isBlank()) list else list.filter { it.name.contains(q, ignoreCase = true) }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val cartLines: StateFlow<List<CartLine>> = combine(products, cart) { list, c ->
        c.mapNotNull { (id, qty) -> list.find { it.id == id }?.let { CartLine(it, qty) } }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun add(p: Product) {
        val cur = cart.value[p.id] ?: 0
        if (cur < p.stock) cart.value = cart.value + (p.id to cur + 1)
    }

    fun decrease(p: Product) {
        val cur = cart.value[p.id] ?: return
        cart.value = if (cur <= 1) cart.value - p.id else cart.value + (p.id to cur - 1)
    }

    fun clearCart() {
        cart.value = emptyMap()
        discount.value = 0
    }

    fun checkout(paid: Long, method: String, onDone: (ReceiptData) -> Unit) {
        val lines = cartLines.value
        if (lines.isEmpty()) return
        val subtotal = lines.sumOf { it.lineTotal }
        val disc = discount.value.coerceIn(0, subtotal)
        val sale = Sale(
            timestamp = System.currentTimeMillis(),
            subtotal = subtotal,
            discount = disc,
            total = subtotal - disc,
            paid = paid,
            method = method
        )
        val items = lines.map {
            SaleItem(
                saleId = 0, productId = it.product.id, productName = it.product.name,
                price = it.product.price, cost = it.product.cost, qty = it.qty
            )
        }
        viewModelScope.launch {
            val id = dao.checkout(sale, items)
            val receipt = ReceiptData(sale.copy(id = id), items)
            lastReceipt.value = receipt
            clearCart()
            onDone(receipt)
        }
    }

    // ---- Produk ----
    fun saveProduct(p: Product) = viewModelScope.launch { dao.upsertProduct(p) }
    fun deleteProduct(p: Product) = viewModelScope.launch { dao.deleteProduct(p) }

    // ---- Laporan ----
    val range = MutableStateFlow(ReportRange.TODAY)

    private fun bounds(r: ReportRange): Pair<Long, Long> {
        val cal = Calendar.getInstance()
        val end = System.currentTimeMillis()
        cal.set(Calendar.HOUR_OF_DAY, 0); cal.set(Calendar.MINUTE, 0)
        cal.set(Calendar.SECOND, 0); cal.set(Calendar.MILLISECOND, 0)
        when (r) {
            ReportRange.TODAY -> {}
            ReportRange.WEEK -> cal.add(Calendar.DAY_OF_YEAR, -6)
            ReportRange.MONTH -> cal.set(Calendar.DAY_OF_MONTH, 1)
        }
        return cal.timeInMillis to end
    }

    val report: StateFlow<ReportState> = range.flatMapLatest { r ->
        val (from, to) = bounds(r)
        combine(dao.salesBetween(from, to), dao.profitBetween(from, to), dao.topProducts(from, to)) { s, p, t ->
            ReportState(s, p, t)
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), ReportState())

    suspend fun itemsOf(saleId: Long) = dao.itemsOf(saleId)
}
