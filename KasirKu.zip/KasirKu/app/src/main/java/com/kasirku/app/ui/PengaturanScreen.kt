package com.kasirku.app.ui

import android.annotation.SuppressLint
import android.widget.Toast
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.Arrangement
import com.kasirku.app.print.BluetoothPrinter

@SuppressLint("MissingPermission")
@Composable
fun PengaturanScreen(prefs: Prefs) {
    val ctx = LocalContext.current
    var store by remember { mutableStateOf(prefs.storeName) }
    var selected by remember { mutableStateOf(prefs.printerAddress) }
    var devices by remember { mutableStateOf(emptyList<Pair<String, String>>()) }

    val loadDevices = rememberBtPermission {
        devices = BluetoothPrinter(ctx).pairedDevices().map { (it.name ?: "Perangkat") to it.address }
        if (devices.isEmpty()) {
            Toast.makeText(ctx, "Pasangkan printer di pengaturan Bluetooth HP dulu", Toast.LENGTH_LONG).show()
        }
    }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("Nama toko (tampil di struk)", fontWeight = FontWeight.Bold)
        OutlinedTextField(
            value = store,
            onValueChange = { store = it; prefs.storeName = it },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )
        Text("Printer Bluetooth", fontWeight = FontWeight.Bold)
        Text(
            "Printer thermal 58mm. Pasangkan dulu lewat pengaturan Bluetooth HP.",
            style = MaterialTheme.typography.bodySmall
        )
        Button(onClick = loadDevices) { Text("Cari printer terpasang") }
        devices.forEach { (name, addr) ->
            Card(Modifier.fillMaxWidth().clickable {
                selected = addr
                prefs.printerAddress = addr
                prefs.printerName = name
            }) {
                Row(Modifier.padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    RadioButton(selected = selected == addr, onClick = {
                        selected = addr
                        prefs.printerAddress = addr
                        prefs.printerName = name
                    })
                    Column {
                        Text(name)
                        Text(addr, style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
        }
        if (devices.isEmpty() && prefs.printerName != null) {
            Text("Printer terpilih: ${prefs.printerName}")
        }
    }
}
