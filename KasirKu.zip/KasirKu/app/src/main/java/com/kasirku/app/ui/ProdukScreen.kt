package com.kasirku.app.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.kasirku.app.data.Product

@Composable
fun ProdukScreen(vm: MainViewModel) {
    val products by vm.products.collectAsStateWithLifecycle()
    var editing by remember { mutableStateOf<Product?>(null) }
    var showForm by remember { mutableStateOf(false) }
    var toDelete by remember { mutableStateOf<Product?>(null) }

    Box(Modifier.fillMaxSize()) {
        if (products.isEmpty()) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("Belum ada produk. Ketuk + untuk menambah.")
            }
        } else {
            LazyColumn(contentPadding = PaddingValues(12.dp, 12.dp, 12.dp, 88.dp)) {
                items(products, key = { it.id }) { p ->
                    Card(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(p.name, fontWeight = FontWeight.SemiBold)
                                Text("${rupiah(p.price)} • Modal ${rupiah(p.cost)}")
                                Text(
                                    "Stok: ${p.stock} • ${p.category}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = if (p.stock <= 5) MaterialTheme.colorScheme.error
                                    else MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            IconButton(onClick = { editing = p; showForm = true }) { Icon(Icons.Default.Edit, "Ubah") }
                            IconButton(onClick = { toDelete = p }) { Icon(Icons.Default.Delete, "Hapus") }
                        }
                    }
                }
            }
        }
        FloatingActionButton(
            onClick = { editing = null; showForm = true },
            modifier = Modifier.align(Alignment.BottomEnd).padding(16.dp)
        ) { Icon(Icons.Default.Add, "Tambah produk") }
    }

    if (showForm) {
        ProductForm(
            initial = editing,
            onDismiss = { showForm = false },
            onSave = { vm.saveProduct(it); showForm = false }
        )
    }
    toDelete?.let { p ->
        AlertDialog(
            onDismissRequest = { toDelete = null },
            title = { Text("Hapus produk?") },
            text = { Text(p.name) },
            confirmButton = { Button(onClick = { vm.deleteProduct(p); toDelete = null }) { Text("Hapus") } },
            dismissButton = { TextButton(onClick = { toDelete = null }) { Text("Batal") } }
        )
    }
}

@Composable
private fun ProductForm(initial: Product?, onDismiss: () -> Unit, onSave: (Product) -> Unit) {
    var name by remember { mutableStateOf(initial?.name ?: "") }
    var price by remember { mutableStateOf(initial?.price?.toString() ?: "") }
    var cost by remember { mutableStateOf(initial?.cost?.toString() ?: "") }
    var stock by remember { mutableStateOf(initial?.stock?.toString() ?: "") }
    var category by remember { mutableStateOf(initial?.category ?: "Umum") }
    val num = KeyboardOptions(keyboardType = KeyboardType.Number)

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (initial == null) "Produk baru" else "Ubah produk") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(name, { name = it }, label = { Text("Nama") }, singleLine = true)
                OutlinedTextField(price, { price = it.filter(Char::isDigit) }, label = { Text("Harga jual") }, keyboardOptions = num, singleLine = true)
                OutlinedTextField(cost, { cost = it.filter(Char::isDigit) }, label = { Text("Harga modal") }, keyboardOptions = num, singleLine = true)
                OutlinedTextField(stock, { stock = it.filter(Char::isDigit) }, label = { Text("Stok") }, keyboardOptions = num, singleLine = true)
                OutlinedTextField(category, { category = it }, label = { Text("Kategori") }, singleLine = true)
            }
        },
        confirmButton = {
            Button(
                enabled = name.isNotBlank() && (price.toLongOrNull() ?: 0L) > 0,
                onClick = {
                    onSave(
                        Product(
                            id = initial?.id ?: 0,
                            name = name.trim(),
                            price = price.toLongOrNull() ?: 0L,
                            cost = cost.toLongOrNull() ?: 0L,
                            stock = stock.toIntOrNull() ?: 0,
                            category = category.ifBlank { "Umum" }
                        )
                    )
                }
            ) { Text("Simpan") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Batal") } }
    )
}
