package com.kasirku.app.data

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "products")
data class Product(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val price: Long,
    val cost: Long = 0,
    val stock: Int = 0,
    val category: String = "Umum"
)

@Entity(tableName = "sales")
data class Sale(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val timestamp: Long,
    val subtotal: Long,
    val discount: Long,
    val total: Long,
    val paid: Long,
    val method: String
)

@Entity(tableName = "sale_items")
data class SaleItem(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    @ColumnInfo(index = true) val saleId: Long,
    val productId: Long,
    val productName: String,
    val price: Long,
    val cost: Long,
    val qty: Int
)

data class TopProduct(val name: String, val qty: Int)

data class CartLine(val product: Product, val qty: Int) {
    val lineTotal: Long get() = product.price * qty
}
