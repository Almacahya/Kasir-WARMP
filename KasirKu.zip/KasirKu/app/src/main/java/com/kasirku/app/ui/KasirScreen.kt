package com.kasirku.app.ui

import android.content.Intent
import android.widget.Toast
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.foundation.text.KeyboardOptions
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.kasirku.app.print.BluetoothPrinter
import com.kasirku.app.print.ReceiptFormatter
import kotlinx.coroutines.launch

@Composable
fun KasirScreen(vm: MainViewModel, prefs: Prefs) {
    val products by vm.filtered.collectAsStateWithLifecycle()
    val search by vm.search.collectAsStateWithLifecycle()
    val cart by vm.cart.collectAsStateWithLifecycle()
    val lines by vm.cartLines.collectAsStateWithLifecycle()
    var showCheckout by remember { mutableStateOf(false) }
    var receipt by remember { mutableStateOf<ReceiptData?>(null) }
    val subtotal = lines.sumOf { it.lineTotal }

    Column(Modifier.fillMaxSize()) {
        OutlinedTextField(
            value = search,
            onValueChange = { vm.search.value = it },
            leadingIcon = { Icon(Icons.Default.Search, null) },
            placeholder = { Text("Cari produk") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth().padding(12.dp)
        )
        if (products.isEmpty()) {
            Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                Text("Belum ada produk. Tambahkan di tab Produk.")
            }
        } else {
            LazyColumn(Modifier.weight(1f), contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 12.dp)) {
                items(products, key = { it.id }) { p ->
                    val qty = cart[p.id] ?: 0
                    Card(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                        Row(
                            Modifier.fillMaxWidth().padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(Modifier.weight(1f)) {
                                Text(p.name, fontWeight = FontWeight.SemiBold)
                                Text(rupiah(p.price), color = MaterialTheme.colorScheme.primary)
                                Text("Stok: ${p.stock}", style = MaterialTheme.typography.bodySmall)
                            }
                            if (qty > 0) {
                                IconButton(onClick = { vm.decrease(p) }) { Icon(Icons.Default.Remove, "Kurangi") }
                                Text("$qty", fontWeight = FontWeight.Bold)
                            }
                            IconButton(onClick = { vm.add(p) }, enabled = qty < p.stock) {
                                Icon(Icons.Default.Add, "Tambah")
                            }
                        }
                    }
                }
            }
        }
        if (lines.isNotEmpty()) {
            Button(
                onClick = { showCheckout = true },
                modifier = Modifier.fillMaxWidth().padding(12.dp)
            ) {
                Text("Bayar ${lines.sumOf { it.qty }} item • ${rupiah(subtotal)}")
            }
        }
    }

    if (showCheckout) {
        CheckoutDialog(vm, onDismiss = { showCheckout = false }, onDone = {
            showCheckout = false
            receipt = it
        })
    }
    receipt?.let { ReceiptDialog(it, prefs) { receipt = null } }
}

@Composable
private fun CheckoutDialog(vm: MainViewModel, onDismiss: () -> Unit, onDone: (ReceiptData) -> Unit) {
    val lines by vm.cartLines.collectAsStateWithLifecycle()
    val discount by vm.discount.collectAsStateWithLifecycle()
    val subtotal = lines.sumOf { it.lineTotal }
    val total = (subtotal - discount).coerceAtLeast(0)
    var method by remember { mutableStateOf("Tunai") }
    var paidText by remember { mutableStateOf("") }
    val paid = if (method == "Tunai") paidText.toLongOrNull() ?: 0L else total
    val enough = paid >= total && total > 0

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Pembayaran") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                lines.forEach {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("${it.qty} x ${it.product.name}", Modifier.weight(1f))
                        Text(rupiah(it.lineTotal))
                    }
                }
                HorizontalDivider(Modifier.padding(vertical = 8.dp))
                OutlinedTextField(
                    value = if (discount == 0L) "" else discount.toString(),
                    onValueChange = { vm.discount.value = it.filter(Char::isDigit).toLongOrNull() ?: 0L },
                    label = { Text("Diskon (Rp)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(8.dp))
                Text("Total: ${rupiah(total)}", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("Tunai", "QRIS", "Transfer").forEach {
                        FilterChip(selected = method == it, onClick = { method = it }, label = { Text(it) })
                    }
                }
                if (method == "Tunai") {
                    OutlinedTextField(
                        value = paidText,
                        onValueChange = { paidText = it.filter(Char::isDigit) },
                        label = { Text("Uang diterima (Rp)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(top = 4.dp)) {
                        OutlinedButton(onClick = { paidText = total.toString() }) { Text("Pas") }
                        listOf(50_000L, 100_000L).forEach {
                            OutlinedButton(onClick = { paidText = it.toString() }) { Text("${it / 1000}rb") }
                        }
                    }
                    if (paid >= total && total > 0) Text("Kembalian: ${rupiah(paid - total)}")
                }
            }
        },
        confirmButton = {
            Button(enabled = enough, onClick = { vm.checkout(paid, method, onDone) }) { Text("Selesaikan") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Batal") } }
    )
}

@Composable
private fun ReceiptDialog(r: ReceiptData, prefs: Prefs, onClose: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val text = ReceiptFormatter.text(prefs.storeName, r)

    val doPrint = rememberBtPermission {
        val addr = prefs.printerAddress
        if (addr == null) {
            Toast.makeText(ctx, "Pilih printer di tab Printer", Toast.LENGTH_LONG).show()
        } else scope.launch {
            val res = BluetoothPrinter(ctx).print(addr, text)
            Toast.makeText(
                ctx,
                if (res.isSuccess) "Struk dicetak" else "Gagal mencetak: ${res.exceptionOrNull()?.message}",
                Toast.LENGTH_LONG
            ).show()
        }
    }

    AlertDialog(
        onDismissRequest = onClose,
        title = { Text("Transaksi berhasil") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                Text(text, fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace, style = MaterialTheme.typography.bodySmall)
            }
        },
        confirmButton = { Button(onClick = doPrint) { Text("Cetak") } },
        dismissButton = {
            Row {
                TextButton(onClick = {
                    val send = Intent(Intent.ACTION_SEND).apply {
                        type = "text/plain"
                        putExtra(Intent.EXTRA_TEXT, text)
                    }
                    ctx.startActivity(Intent.createChooser(send, "Bagikan struk"))
                }) { Text("Bagikan") }
                Spacer(Modifier.width(4.dp))
                TextButton(onClick = onClose) { Text("Tutup") }
            }
        }
    )
}
