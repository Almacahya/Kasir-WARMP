package com.kasirku.app.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Card
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun LaporanScreen(vm: MainViewModel) {
    val range by vm.range.collectAsStateWithLifecycle()
    val report by vm.report.collectAsStateWithLifecycle()
    val df = SimpleDateFormat("dd MMM HH:mm", Locale("id", "ID"))

    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = androidx.compose.foundation.layout.PaddingValues(12.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                ReportRange.values().forEach {
                    FilterChip(selected = range == it, onClick = { vm.range.value = it }, label = { Text(it.label) })
                }
            }
        }
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                StatCard("Omzet", rupiah(report.revenue), Modifier.weight(1f))
                StatCard("Laba", rupiah(report.profit), Modifier.weight(1f))
            }
        }
        item { StatCard("Jumlah transaksi", report.sales.size.toString(), Modifier.fillMaxWidth()) }
        if (report.top.isNotEmpty()) {
            item { Text("Produk terlaris", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold) }
            items(report.top) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text(it.name)
                    Text("${it.qty} terjual")
                }
            }
        }
        item { Text("Riwayat transaksi", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold) }
        if (report.sales.isEmpty()) item { Text("Belum ada transaksi pada periode ini.") }
        items(report.sales, key = { it.id }) { s ->
            Card(Modifier.fillMaxWidth()) {
                Row(
                    Modifier.fillMaxWidth().padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Text("#${s.id} • ${s.method}", fontWeight = FontWeight.SemiBold)
                        Text(df.format(Date(s.timestamp)), style = MaterialTheme.typography.bodySmall)
                    }
                    Text(rupiah(s.total), fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
private fun StatCard(label: String, value: String, modifier: Modifier) {
    Card(modifier) {
        Column(Modifier.padding(12.dp)) {
            Text(label, style = MaterialTheme.typography.bodySmall)
            Text(value, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        }
    }
}
