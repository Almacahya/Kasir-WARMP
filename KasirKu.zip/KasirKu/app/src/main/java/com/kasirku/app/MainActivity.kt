package com.kasirku.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BarChart
import androidx.compose.material.icons.filled.Inventory2
import androidx.compose.material.icons.filled.Print
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import com.kasirku.app.ui.KasirScreen
import com.kasirku.app.ui.LaporanScreen
import com.kasirku.app.ui.MainViewModel
import com.kasirku.app.ui.PengaturanScreen
import com.kasirku.app.ui.Prefs
import com.kasirku.app.ui.ProdukScreen

private data class Tab(val title: String, val icon: ImageVector)

class MainActivity : ComponentActivity() {
    private val vm: MainViewModel by viewModels()

    @OptIn(ExperimentalMaterial3Api::class)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = Prefs(this)
        val tabs = listOf(
            Tab("Kasir", Icons.Default.ShoppingCart),
            Tab("Produk", Icons.Default.Inventory2),
            Tab("Laporan", Icons.Default.BarChart),
            Tab("Printer", Icons.Default.Print)
        )
        setContent {
            val dark = isSystemInDarkTheme()
            val scheme = if (dark) darkColorScheme(primary = Color(0xFF7CC8A0))
            else lightColorScheme(primary = Color(0xFF0F7B5A))
            MaterialTheme(colorScheme = scheme) {
                var tab by remember { mutableIntStateOf(0) }
                Scaffold(
                    topBar = { CenterAlignedTopAppBar(title = { Text(tabs[tab].title) }) },
                    bottomBar = {
                        NavigationBar {
                            tabs.forEachIndexed { i, t ->
                                NavigationBarItem(
                                    selected = tab == i,
                                    onClick = { tab = i },
                                    icon = { Icon(t.icon, t.title) },
                                    label = { Text(t.title) }
                                )
                            }
                        }
                    }
                ) { pad ->
                    Surface(Modifier.padding(pad)) {
                        when (tab) {
                            0 -> KasirScreen(vm, prefs)
                            1 -> ProdukScreen(vm)
                            2 -> LaporanScreen(vm)
                            else -> PengaturanScreen(prefs)
                        }
                    }
                }
            }
        }
    }
}
